var count = 0;
var selectNum = [];
var gameNumber= ["col-md-1", "col-sm-1", "col-xs-1", "keno-game-style", "first-column", "keno-number",];
var kenoNums = 1;
var num = [];
var i = 0;
var arr = [];
var compScore1 = [];
$(document).ready(function(){

	$(".lets-play").on("click", function(e){
		var number1 = $("#number1").val();
		var number2 = $("#number2").val();
		var number3 = $("#number3").val();
		var number4 = $("#number4").val();
		var number5 = $("#number5").val();
		var arr = [];
		// stop automatic refresh
		e.preventDefault();
		// timer countdown
		startCountDown();
		// Start the guessing of random numbers
		pickComputerNumbers(arr);
		// for numbers picked highlight them one by one;
		matchNumbers();
	});
});



for (var board = 0; board < 10; board++) {
	for (count = 0; count < 8; kenoNums++ ){
		count++;
		$("#theGame").append("<div class='"+	gameNumber[0]+""+gameNumber[1]+""+gameNumber[2]+" "+gameNumber[3]+" "+gameNumber[4]+" "+gameNumber[5]+" ' data-type='"+count+"'>"+kenoNums+"</div>")
	}
};

// pick computer numbers function
function pickComputerNumbers(arr){
	while(arr.length < 20){
 	 var randomnumber=Math.ceil(Math.random()*80)
	  var found=false;
	  for(var i=0;i<arr.length;i++){
		if(arr[i]==randomnumber){found=true;break}
	  }
	  if(!found)arr[arr.length]=randomnumber;
	}
	console.log(arr);
	compScore1 = arr[0];
	compScore2 = arr[1];
	compScore3 = arr[2];
	compScore4 = arr[3];
	compScore5 = arr[4];
	compScore6 = arr[5];
	compScore7 = arr[6];
	compScore8 = arr[7];
	compScore9 = arr[8];
	compScore10 = arr[9];
	compScore11 = arr[10];
	compScore12 = arr[11];
	compScore13 = arr[12];
	compScore14 = arr[13];
	compScore15 = arr[14];
	compScore16 = arr[15];
	compScore17 = arr[16];
	compScore18 = arr[17];
	compScore19 = arr[18];
	compScore20 = arr[19];
}

function matchNumbers(){
	for(var i = 0; i < 20; i++){
		i++;
			// compScore1 = $(".keno-number").val();
			// $("compScore1").addClass("selected");
			arr [0] = $(".keno-number").addClass("selected").val(); 
		};
	// $(".keno-number").val()

	}







function startCountDown(){
	$("#mainDisplay").hide();
	$(".countDown").css("display","block");
	$("#red").animate({
		fontSize: "2em",
		color: "red",
		duration: 1000}, "slow", function(){
		$("#yellow").animate({
			fontSize: "2em",
			color: "yellow",
			duration: 2000}, "slow", function(){
			$("#green").animate({
				fontSize: "2em",
				color: "green",
				duration: 3000}, "slow", function(){
				$("#go").animate({
					fontSize: "3em",
					duration: 3000}, "slow", function(){
						// bring up the game
						// window.location.replace("thegame.html");
						$(".countDown").hide();
						$("#theGame").css("display", "block");
				});
			});
		});
	});

}



// function selectNum
// count 20 numbers
// function selectNum() {
// 	for(var i = 0; i < 20; i++){
// 		i++;
// 		num = Math.random() * 100;
// 		selectNum.push(num);
// 		while(num > 80){
// 			return false;
// 		}
		
// 	}
// }
// for until i = 20
// math.random select num push num
// while num > 80



// for loop
// loop through the numebrs until it gets to 20
// during the loop if the value in the array compScore = the value in the class then match it and style it

// for(var i = 0; i < 21; i++){
// 	if(compScore1 == $("#one").val()){
// 		$("#one").addClass("computerScore");
// 	}
// }
// }

// for loop to count the rows
// 	inner for loop to build each row of 8

// 		build a div class and value

// 		if that div has 






// function computerNumberList(){
// 	var allNum = $('.keno-number');

// function computerNumberList(){
// 	for each (arr[i] in arr) {
// 		$(".keno-number").() == compScore1 (arr[i]);
// 		$(this).css("background", "yellow");
// 	}
// }

// 	for each arr[i] in arr {
// 		find data-attr/id == currentNum (arr[i]);
// 			do a css/js thing to dom.
// }

// function - animate the countdown
// Switch to the new page






